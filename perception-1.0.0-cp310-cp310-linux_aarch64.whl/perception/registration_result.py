from autolab_core import RigidTransform


class RegistrationResult:
    def __init__(self, T_source_target: RigidTransform, cost: float):
        ...

    @property
    def T_source_target(self) -> RigidTransform:
        ...

    @property
    def cost(self) -> float:
        ...

    def __repr__(self):
        ...