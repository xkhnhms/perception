import numpy as np
from autolab_core import RigidTransform

class ObjectRender:
    def __init__(self, image, T_camera_world=RigidTransform(rotation=np.eye(3), translation=[0, 0, 0], from_frame='camera', to_frame='table'), obj_key=None, stable_pose=None):
        ...
    
    def T_obj_camera(self):
        ...

if __name__ == "__main__":
    ...