from enum import Enum
from autolab_core import RigidTransform
from meshpy.stable_pose import StablePose

import numpy as np
from perception.image import Image

class RenderMode(Enum):
    ...



class ObjectRender:
    def __init__(self, image: Image, T_camera_world: RigidTransform = None, obj_key=None, stable_pose: StablePose = None):
        ...

    def T_obj_camera(self) -> RigidTransform:
        ...

    def __repr__(self):
        ...