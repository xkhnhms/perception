import numpy as np
import cv2


class GrayscaleImage:
    def __init__(self, data, frame='unspecified'):
        ...

    def resize(self, size, interp='bilinear'):
        """
        Resize the image.
        """
        ...

    @staticmethod
    def open(filename, frame='unspecified'):
        """
        Creates a GrayscaleImage from a file.
        """
        ...