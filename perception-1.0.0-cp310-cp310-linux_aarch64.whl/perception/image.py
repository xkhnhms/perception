from enum import Enum
from autolab_core import RigidTransform
from meshpy.stable_pose import StablePose

import numpy as np

class Image:
    """
    Abstract wrapper class for images.
    """
    
    def __init__(self, data, frame='unspecified'):
        ...
    
    @property
    def shape(self):
        return self.data.shape
    
    @property
    def height(self):
        return self.data.shape[0]
    
    @property
    def width(self):
        return self.data.shape[1]
    
    @property
    def center(self):
        return np.array([self.height // 2, self.width // 2])
    
    @property
    def channels(self):
        if self.data.ndim > 2:
            return self.data.shape[2]
        else:
            return 1
    
    @property
    def type(self):
        return self.data.dtype
    
    @property
    def raw_data(self):
        return self.data
    
    def resize(self, size, interp='bilinear'):
        ...
    
    def transform(self, translation, theta, method='opencv'):
        ...
    
    def gradients(self):
        ...
    
    def ij_to_linear(self, i, j):
        return np.ravel_multi_index((i, j), (self.height, self.width))
    
    def linear_to_ij(self, linear_inds):
        return np.unravel_index(linear_inds, (self.height, self.width))
    
    def mask_by_ind(self, inds):
        ...
    
    def mask_by_linear_ind(self, linear_inds):
        ...
    
    def is_same_shape(self, other_im, check_channels=False):
        ...
    
    @staticmethod
    def median_images(images):
        ...
    
    @staticmethod
    def min_images(images):
        ...
    
    def __getitem__(self, indices):
        return self.data[indices]
    
    def apply(self, method, *args, **kwargs):
        ...
    
    def copy(self):
        ...
    
    def crop(self, height, width, center_i=None, center_j=None):
        ...

