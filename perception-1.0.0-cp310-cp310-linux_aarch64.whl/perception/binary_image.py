import numpy as np
import cv2
from skimage import measure
from perception.color_image import ColorImage


class BinaryImage:
    def __init__(self, data, frame='unspecified', threshold=128):
        ...

    def resize(self, size, interp='bilinear'):
        ...

    def mask_binary(self, binary_im):
        ...

    def find_contours(self, min_area=0.0, max_area=float('inf')):
        """
        Returns a list of connected components with an area between min_area and max_area.
        """
        ...

    def contour_mask(self, contour):
        """
        Generates a binary image with only the given contour filled in.
        """
        ...

    def boundary_map(self):
        """
        Computes the boundary pixels in the image and sets them to nonzero values.
        """
        ...

    def closest_nonzero_pixel(self, pixel, direction, w=13, t=0.5):
        """
        Starting at pixel, moves pixel by direction * t until there is a non-zero pixel within a radius w of pixel.
        """
        ...

    def add_frame(self, left_boundary, right_boundary, upper_boundary, lower_boundary):
        """
        Adds a frame to the image.
        """
        ...

    def most_free_pixel(self):
        """
        Find the black pixel with the largest distance from the white pixels.
        """
        ...

    def diff_with_target(self, binary_im):
        """
        Creates a color image to visualize the overlap between two images.
        """
        ...

    def num_adjacent(self, i, j):
        """
        Counts the number of adjacent nonzero pixels to a given pixel.
        """
        ...

    def to_sdf(self):
        """
        Converts the 2D image to a 2D signed distance field.
        """
        ...

    def to_color(self):
        """
        Creates a ColorImage from the binary image.
        """
        ...

    @staticmethod
    def open(filename, frame='unspecified'):
        """
        Creates a BinaryImage from a file.
        """
        ...