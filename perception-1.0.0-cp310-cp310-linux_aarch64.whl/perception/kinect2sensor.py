import numpy as np
from autolab_core import CameraIntrinsics

from perception.color_image import ColorImage
from perception.depth_image import DepthImage
from perception.ir_image import IrImage

class Kinect2PacketPipelineMode:
    ...

class Kinect2RegistrationMode:
    ...

class Kinect2DepthMode:
    ...


class Kinect2Sensor:
    def __init__(self, packet_pipeline_mode=1, registration_mode=1, depth_mode=0, device_num=0, frame=None):
        ...
        
    def __del__(self):
        self.stop()
        
    @property
    def color_intrinsics(self):
        ...

    @property
    def ir_intrinsics(self):
        ...

    @property
    def is_running(self):
        return self._is_running

    @property
    def frame(self):
        return self._frame

    @frame.setter
    def frame(self, value):
        self._frame = value

    @property
    def color_frame(self):
        return self.frame + '_color'

    @property
    def ir_frame(self):
        return self.frame + '_ir'
    
    def start(self):
        ...

    def stop(self):
        ...
    
    def frames(self, skip_registration=False):
        ...

    def median_depth_img(self, num_img=1):
        ...

