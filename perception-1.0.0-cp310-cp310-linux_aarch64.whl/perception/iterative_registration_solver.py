from abc import ABC, abstractmethod
import numpy as np

class RegistrationResult:
    def __init__(self, transformation_matrix, cost):
       ...

class IterativeRegistrationSolver(ABC):
    @abstractmethod
    def register(self, source_point_cloud, target_point_cloud, source_normal_cloud, target_normal_cloud, matcher, num_iterations=1, compute_total_cost=True, match_centroids=False, vis=False):
        pass

# 示例具体实现类
class ExampleIterativeRegistrationSolver(IterativeRegistrationSolver):
    def register(self, source_point_cloud, target_point_cloud, source_normal_cloud, target_normal_cloud, matcher, num_iterations=1, compute_total_cost=True, match_centroids=False, vis=False):
        ...


