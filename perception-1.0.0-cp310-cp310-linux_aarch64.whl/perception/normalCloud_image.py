import numpy as np
from autolab_core import NormalCloud
import cv2


class NormalCloudImage:
    def __init__(self, data, frame='unspecified'):
        ...
    
    def resize(self, size, interp='bilinear'):
        ...
    
    def to_normal_cloud(self):
        ...

    @staticmethod
    def open(filename, frame='unspecified'):
        ...

