import numpy as np
import cv2
from autolab_core import PointCloud


class PointCloudImage:
    def __init__(self, data, frame='unspecified'):
        ...
    
    def resize(self, size, interp='bilinear'):
        ...

    def to_point_cloud(self):
        ...

    def normal_cloud_im(self):
        ...

    @staticmethod
    def open(filename, frame='unspecified'):
        ...