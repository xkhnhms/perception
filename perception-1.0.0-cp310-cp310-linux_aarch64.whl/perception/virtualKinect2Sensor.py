import os
import numpy as np
from glob import glob
import cv2

from autolab_core import CameraIntrinsics

from perception.color_image import ColorImage
from perception.depth_image import DepthImage
from perception.ir_image import IrImage


class VirtualKinect2Sensor:
    def __init__(self, path_to_images, frame=None):
        ...
        
    @property
    def is_running(self):
        return self._is_running
    
    @property
    def color_frame(self):
        return self.frame + '_color'
    
    @property
    def ir_frame(self):
        return self.frame + '_ir'
    
    def start(self):
        ...
    
    def stop(self):
        ...
    
    def frames(self):
        ...
    
    def median_depth_img(self, num_img=1):
        ...

if __name__=='__main__':
    ...