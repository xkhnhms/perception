import numpy as np
import cv2

from perception.color_image import ColorImage
from perception.binary_image import BinaryImage

class DepthImage:
    def __init__(self, data, frame='unspecified'):
        ...

    def resize(self, size, interp='bilinear'):
        """
        Resize the image.
        """
        ...

    def threshold(self, front_thresh=0.0, rear_thresh=100.0):
        """
        Creates a new DepthImage by setting all depths less than front_thresh and greater than rear_thresh to 0.
        """
        ...

    def threshold_gradients(self, grad_thresh):
        """
        Creates a new DepthImage by zeroing out all depths where the magnitude of the gradient at that point is greater than grad_thresh.
        """
        ...

    def threshold_gradients_pctile(self, thresh_pctile, min_mag=0.0):
        """
        Creates a new DepthImage by zeroing out all depths where the magnitude of the gradient at that point is greater than some percentile of all gradients.
        """
        ...

    def inpaint(self, rescale_factor=1.0):
        """
        Fills in the zero pixels in the image.
        """
        ...

    def mask_binary(self, binary_im):
        """
        Create a new image by zeroing out data at locations where binary_im == 0.0.
        """
        ...

    def pixels_farther_than(self, depth_im):
        """
        Returns the pixels that are farther away than those in the corresponding depth image.
        """
        ...

    def combine_with(self, depth_im):
        """
        Replaces all zeros in the source depth image with the value of a different depth image.
        """
        ...

    def to_binary(self, threshold=0.0):
        """
        Creates a BinaryImage from the depth image.
        """
        ...

    def to_color(self, normalize=False):
        """
        Convert to a color image.
        """
        ...

    def to_float(self):
        """
        Converts to 32-bit data.
        """
        ...

    @staticmethod
    def open(filename, frame='unspecified'):
        """
        Creates a DepthImage from a file.
        """
        ...