import cv2
import time
import threading


class VideoRecorder:
    def __init__(self, device_id=0, res=(640, 480), codec='XVID', fps=30):
        ...

    def start(self):
        ...

    def start_recording(self, output_file):
        ...

    def stop_recording(self):
        ...

    def stop(self):
        ...

    def _capture_loop(self):
        ...