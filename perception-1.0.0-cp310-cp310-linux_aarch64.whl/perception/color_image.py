import numpy as np
import cv2
from skimage import color
from sklearn.cluster import KMeans

from perception.image import Image
from perception.binary_image import BinaryImage
from perception.segmentation_image import SegmentationImage
from perception.grayscale_image import GrayscaleImage

class ColorImage(Image):
    """
    An RGB color image.
    """

    def __init__(self, data, frame='unspecified'):
        ...

    @property
    def r_data(self):
        return self.data[:, :, 0]

    @property
    def g_data(self):
        return self.data[:, :, 1]

    @property
    def b_data(self):
        return self.data[:, :, 2]

    def swap_channels(self, channel_swap):
        """
        Swaps the two channels specified in the tuple.

        Parameters:
            channel_swap (tuple of int): The two channels to swap
        Returns:
            ColorImage: color image with cols swapped
        """
        ...

    def find_chessboard(self, sx=6, sy=9):
        ...

    def mask_binary(self, binary_im):
        ...

    def foreground_mask(self, tolerance, ignore_black=True, use_hsv=False, scale=8, bgmodel=None):

        ...

    def background_model(self, ignore_black=True, use_hsv=False, scale=8):
        ...

    def draw_box(self, box):
        """
        Draws a white box on the image.
        :param box: autolab_core.Box
        :return: ColorImage
        """
        ...

    def nonzero_hsv_data(self):
        ...

    def segment_kmeans(self, rgb_weight, num_clusters, hue_weight=0.0):

        ...

    def inpaint(self, win_size=3, rescale_factor=1.0):
        ...

    def to_binary(self, threshold=0.0):

        ...

    def to_grayscale(self):

        ...

    @staticmethod
    def open(filename, frame='unspecified'):
        ...