import numpy as np
import cv2


class IrImage:
    def __init__(self, data, frame='unspecified'):
        ...

    def resize(self, size, interp='bilinear'):
        """
        Resize the image.
        """
        ...

    @staticmethod
    def open(filename, frame='unspecified'):
        """
        Creates an IrImage from a file.
        """
        ...