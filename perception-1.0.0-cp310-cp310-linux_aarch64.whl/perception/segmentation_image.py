import numpy as np
from skimage.filters import gaussian
from skimage.segmentation import find_boundaries
import cv2

from perception.binary_image import BinaryImage

class SegmentationImage:
    def __init__(self, data, frame='unspecified'):
        ...

    def border_pixels(self, grad_sigma=0.5, grad_lower_thresh=0.1, grad_upper_thresh=1.0):
        ...

    def segment_mask(self, segnum):
        ...

    def resize(self, size, interp='nearest'):
        ...

    @staticmethod
    def open(filename, frame='unspecified'):
        ...
