import numpy as np
import os
import json
from autolab_core import PointCloud, Point, ImageCoords, DepthImage, PointCloudImage


class CameraIntrinsics:
    def __init__(self, frame, fx, fy=None, cx=0.0, cy=0.0, skew=0.0, height=None, width=None):
        """
        Initialize a CameraIntrinsics model.

        Parameters:
        -----------
        frame : str
            The frame of reference for the point cloud.
        fx : float
            Focal length along x-axis in pixels.
        fy : float, optional
            Focal length along y-axis in pixels (defaults to fx).
        cx : float, optional
            X-axis optical center in pixels.
        cy : float, optional
            Y-axis optical center in pixels.
        skew : float, optional
            Skew coefficient.
        height : float, optional
            Height of image in pixels.
        width : float, optional
            Width of image in pixels.
        """
        ...

    @property
    def frame(self):
        return self._frame

    @property
    def fx(self):
        return self._fx

    @property
    def fy(self):
        return self._fy

    @property
    def cx(self):
        return self._cx

    @property
    def cy(self):
        return self._cy

    @property
    def skew(self):
        return self._skew

    @property
    def height(self):
        return self._height

    @property
    def width(self):
        return self._width

    @property
    def K(self):
        return self._K.copy()

    @property
    def proj_matrix(self):
        return self.K

    def crop(self, height, width, crop_ci, crop_cj):
        """
        Convert to new camera intrinsics for a cropped window.

        Parameters:
        -----------
        height : int
            Height of the crop window.
        width : int
            Width of the crop window.
        crop_ci : int
            Row (y) of the crop window center.
        crop_cj : int
            Column (x) of the crop window center.
        """
        ...

    def resize(self, scale):
        """
        Convert to new camera intrinsics for a resized image.

        Parameters:
        -----------
        scale : float
            Scale factor to apply to intrinsics.
        """
        ...

    def project(self, point_cloud, round_px=True):
        """
        Projects a point cloud onto the camera image plane.

        Parameters:
        -----------
        point_cloud : PointCloud or Point
            A PointCloud or Point to project onto the image plane.
        round_px : bool
            If True, pixel coordinates are rounded to nearest integer.

        Returns:
        --------
        ImageCoords or Point
            Projected image coordinates.
        """
        ...

    def project_to_image(self, point_cloud, round_px=True):
        """
        Projects a point cloud into a depth image.

        Parameters:
        -----------
        point_cloud : PointCloud
            Input point cloud.
        round_px : bool
            Whether to round pixel coordinates.

        Returns:
        --------
        DepthImage
            Generated depth image.
        """
        ...

    def deproject(self, depth_image):
        """
        Deprojects a depth image into a 3D point cloud.

        Parameters:
        -----------
        depth_image : DepthImage
            Input depth image.

        Returns:
        --------
        PointCloud
            Reconstructed 3D point cloud.
        """
        ...

    def deproject_to_image(self, depth_image):
        """
        Deprojects a depth image into a point cloud image.

        Parameters:
        -----------
        depth_image : DepthImage
            Input depth image.

        Returns:
        --------
        PointCloudImage
            Reconstructed 3D point cloud image.
        """
        ...

    def deproject_pixel(self, depth, pixel):
        """
        Deproject a single pixel with given depth.

        Parameters:
        -----------
        depth : float
            Depth at pixel location.
        pixel : Point
            Pixel coordinate in image plane.

        Returns:
        --------
        Point
            3D point in camera frame.
        """
        ...

    def save(self, filename):
        """
        Save the CameraIntrinsics object to a .intr file.

        Parameters:
        -----------
        filename : str
            File path ending with .intr
        """
        ...

    @staticmethod
    def load(filename):
        """
        Load a CameraIntrinsics object from a .intr file.

        Parameters:
        -----------
        filename : str
            File path ending with .intr

        Returns:
        --------
        CameraIntrinsics
        """
        ...
    
if __name__=='__main__':
    # 创建相机参数
    intr = CameraIntrinsics(
        frame="camera",
        fx=525.0,
        fy=525.0,
        cx=319.5,
        cy=239.5,
        width=640,
        height=480
    )

    # 创建一个简单的点云
    points = np.array([
        [0.1, 0.2, 1.0],
        [0.3, 0.4, 1.5],
        [0.5, 0.6, 2.0]
    ]).T
    pc = PointCloud(points, frame="camera")

    # 投影到图像平面
    image_coords = intr.project(pc)
    print("Projected image coordinates:\n", image_coords.data)

    # 反投影生成深度图
    depth_image = intr.project_to_image(pc)
    print("Generated depth image shape:", depth_image.shape)

    # 再从深度图重建点云
    reconstructed_pc = intr.deproject(depth_image)
    print("Reconstructed point cloud:\n", reconstructed_pc.data)

    # 保存和加载
    intr.save("camera.intr")
    loaded_intr = CameraIntrinsics.load("camera.intr")