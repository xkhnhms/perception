import numpy as np
from autolab_core import RigidTransform, PointCloud, NormalCloud
from scipy.spatial.transform import Rotation as R

from perception.iterative_registration_solver import IterativeRegistrationSolver
from perception.registration_result import RegistrationResult


class PointToPlaneICPSolver(IterativeRegistrationSolver):
    def __init__(self, sample_size=100, cost_sample_size=100, gamma=100.0, mu=0.01):
        ...

    def register(self, source_point_cloud, target_point_cloud,
                 source_normal_cloud, target_normal_cloud,
                 matcher, num_iterations=1, compute_total_cost=True,
                 match_centroids=False, vis=False):
        ...

    def register_2d(self, source_point_cloud, target_point_cloud,
                    source_normal_cloud, target_normal_cloud,
                    matcher, num_iterations=1, compute_total_cost=True, vis=False):
        ...

    def _transform_points(self, pts, T):
        ...

    def _transform_points_2d(self, pts, theta, t):
        ...

    def _build_system(self, src, tgt, normals):
        ...

    def _build_system_2d(self, src, tgt, normals):
        ...

    def _compute_cost(self, src, tgt, normals):
        ...

    def _compute_cost_2d(self, src, tgt, normals):
        ...

    def _exp_se3(self, xi):
        ...

    def _hat(self, vec):
        ...