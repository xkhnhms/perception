from perception.virtualKinect2Sensor import VirtualKinect2Sensor
from perception.kinect2sensor import Kinect2Sensor

class Kinect2SensorFactory:
    @staticmethod
    def sensor(sensor_type, cfg):
        ...

